create or replace function customer_total_order (c_t_o in customer.cus_id%type)  
return number is 
   total integer := 0; 
begin 
   select count(cus_id) into total from customer natural join courier where cus_id = c_t_o; 
    
   return total; 
end; 

create or replace function courier_status (c_s in courier.cou_id%type)  
return varchar IS 
   sta_tus varchar(20); 
begin
   select status into sta_tus from courier where cou_id=c_s; 
    
   return sta_tus; 
end;

create or replace function dep_time(d_t in freight.fre_no%type)
	return varchar as 
	dep_t varchar(20);
	
	Begin
	select dep_time into dep_t from freight where fre_no=d_t;

	return dep_t;
	
end;

set serveroutput on
declare
cus_id integer;
cou_id integer;
fre_no integer;

begin 
    cus_id:= 10;
    dbms_output.put_line('    till now customer id 10 has send --> '||customer_total_order(cus_id)||' courier');
    cou_id:= 10;
    dbms_output.put_line('    now the status for courier 10 is --> '||courier_status (cou_id)); 
    fre_no:= 1;
    dbms_output.put_line('    departure time for freight 1 is --> '||dep_time (fre_no)); 
end;


