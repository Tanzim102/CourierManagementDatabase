insert into courier (cou_id,sou_off_id,des_off_id,entry_time,fre_no,cus_id,rec_phone) values (26,1,10,to_date('26/06/2018','DD/MM/YYYY'),2,9,'01600000001');
select * from courier;
