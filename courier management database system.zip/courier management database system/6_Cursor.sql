set serveroutput on
declare
cursor c_name is 
select * from courier where cus_id=10;
c_record c_name%rowtype;

begin
dbms_output.put_line('For Customer id 10');
open c_name;
loop
fetch c_name into c_record;
exit when c_name %notfound;
--dbms_output.put_line('Courier Number: '||c_record.cou_id|| ' and Customer ID : '||c_record.cus_id);
dbms_output.put_line('    Courier id is: '||c_record.cou_id);
end loop;
close c_name;
 
declare
type namearray is varray(1000000) of freight.total_service%type;
  
noo namearray :=namearray();
no_max number(2);
no_min number(2);
counter number(3);
begin
for counter in 1..10
loop
 
noo.extend;
 
 select max(total_service) into no_max from freight;
 select min(total_service) into no_min from freight;
 
end loop;
 dbms_output.put_line('maximun service given by any freight is --> '||no_max||' and');
 

 declare
cursor c_name2 is 
select fre_no from freight where total_service=no_max;
c_record c_name2%rowtype;

begin
open c_name2;
loop
fetch c_name2 into c_record;
exit when c_name2 %notfound;
dbms_output.put_line('         the Freight number is: '||c_record.fre_no);
end loop;
close c_name2;
end;

 dbms_output.put_line('minimum service given by any freight is --> '||no_min||' and');
 

 declare
cursor c_name3 is 
select fre_no from freight where total_service=no_min;
c_record c_name3%rowtype;

begin
open c_name3;
loop
fetch c_name3 into c_record;
exit when c_name3 %notfound;
dbms_output.put_line('         the Freight number is: '||c_record.fre_no);
end loop;
close c_name3;
end;


end;
end;
/